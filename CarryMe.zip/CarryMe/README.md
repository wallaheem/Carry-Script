# CarryMe Script

CarryMe is a lightweight and optimized carry system for FiveM that supports both **ESX** and **QBCore** frameworks. This script allows authorized jobs to initiate and stop a carry animation on nearby players using a simple command.

## 🔧 Features
- Framework auto-detection (ESX or QBCore)
- Carry command: `/carryme`
- Restriction to **EMS** (`ambulance`) and **PD** (`police`) jobs
- Clean animation transitions
- Optimized and minimal performance impact
- Built-in notification system (supports `lib.notify` or default GTA help texts)

## 📦 Installation
1. Place the `CarryMe` folder into your `resources` directory.
2. Ensure it is started in your `server.cfg`:
   ```
   ensure CarryMe
   ```
3. Make sure you have either **es_extended** or **qb-core** running.

## 🧠 Usage
- Use `/carryme` to carry the closest player within 3 meters.
- Use the same command to cancel the carry.
- Only EMS and PD jobs can initiate carrying.

## 📋 Notes
- Compatible with both **OneSync** and non-OneSync environments.
- Optionally integrates with `ox_lib` for modern UI notifications.

## 💬 Support
For questions or custom modifications, reach out to the original developer.

---
Created by **Wallaheem**
