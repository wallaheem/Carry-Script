-- Resource Metadata
fx_version 'bodacious'
games { 'gta5' }

author 'Wallaheem'
description 'Carry'
version '1.0.0'

client_script "cl_carry.lua"
server_script "sv_carry.lua"


-- Framework Support
dependency "es_extended"
--dependency "qb-core"
